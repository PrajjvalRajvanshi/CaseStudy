package com.cg.payroll.daoservices;

import java.util.ArrayList;
import java.util.List;
import com.cg.payroll.bean.Associate;
import com.cg.payroll.util.PayrollDBUtill;

public class AssociateDAOImpl  implements AssociateDAO{

	@Override
	public Associate save(Associate associate) {
		associate.setAssociateId(PayrollDBUtill.getASSOCIATE_ID_COUNTER());
		PayrollDBUtill.associates.put(associate.getAssociateId(),associate);
		return associate;
	}

	@Override
	public boolean update(Associate associate) {
		
		return false;
	}

	@Override
	public Associate findOne(int associate) {
		return PayrollDBUtill.associates.get(associate);
	}

	@Override
	public List<Associate> findAll() {
	ArrayList<Associate> associatesList=new ArrayList<>(PayrollDBUtill.associates.values());
	return associatesList;
	}

}
